import 'package:fitness_dashboard_ui/models/schedule_model.dart';

class ScheduleTasksData {
  final scheduled = const [
    ScheduledModel(
        title: "Strength Training",
        date: "Squats (3 sets x 10 reps)               Today, 9AM - 10AM"),
    ScheduledModel(
        title: "Cardiovascular Exercise",
        date: "Running or Jogging                    Tomorrow, 5PM - 6PM"),
    ScheduledModel(
        title: "High-Intensity Interval Training (HIIT)",
        date: "Burpees, jumping jacks         Wednesday, 9AM - 10AM"),
  ];
}
