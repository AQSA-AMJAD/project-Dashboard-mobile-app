import 'package:fitness_dashboard_ui/models/menu_model.dart';
import 'package:flutter/material.dart';

class SideMenuData {
  final menu = const <MenuModel>[
    MenuModel(icon: Icons.home, title: 'Dashboard'),
    MenuModel(icon: Icons.person, title: 'My Profile'),
    MenuModel(icon: Icons.run_circle, title: 'Workouts'),
    MenuModel(icon: Icons.local_activity, title: 'Activity Tracker'),
    MenuModel(icon: Icons.sports_football, title: 'Challenges and Goals'),
    MenuModel(icon: Icons.share, title: 'Social Sharing'),
    MenuModel(icon: Icons.history, title: 'History'),
    MenuModel(icon: Icons.settings, title: 'Settings'),
    MenuModel(icon: Icons.logout, title: 'SignOut'),
  ];
}
