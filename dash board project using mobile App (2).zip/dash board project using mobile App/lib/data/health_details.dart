import 'package:fitness_dashboard_ui/models/health_model.dart';

class HealthDetails {
  final healthData = const [
    HealthModel(
        icon: 'assets/icons/burn.png', value: "550", title: "Energy Expended"),
    HealthModel(
        icon: 'assets/icons/steps.png', value: "25,430", title: "Footsteps"),
    HealthModel(
        icon: 'assets/icons/distance.png',
        value: "18km",
        title: "Stride Distance"),
    HealthModel(
        icon: 'assets/icons/sleep.png',
        value: "8-Hours",
        title: "Rest Duration"),
  ];
}
