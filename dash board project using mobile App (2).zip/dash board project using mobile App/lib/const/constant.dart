import 'package:flutter/material.dart';

const cardBackgroundColor = Color.fromARGB(255, 43, 45, 44);
const primaryColor = Color.fromARGB(255, 91, 154, 213);
const secondaryColor = Color.fromARGB(255, 94, 32, 32);
const backgroundColor = Color.fromARGB(255, 97, 152, 144);
const selectionColor = Color.fromARGB(255, 114, 232, 215);

const defaultPadding = 20.0;
