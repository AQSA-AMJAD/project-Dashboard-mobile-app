class ScheduledModel {
  final String title;
  final String date;

  const ScheduledModel({required this.title, required this.date});
}
